

package negocio;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.QueryParam;
import javax.ws.rs.FormParam;
import javax.ws.rs.core.Response;

import java.sql.*;
import javax.sql.DataSource;
import javax.naming.Context;
import javax.naming.InitialContext;

import java.util.ArrayList;
import com.google.gson.*;

import java.time.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ArrayList;


@Path("ws")
public class Servicio
{
  static DataSource pool = null;
  static
  {		
    try
    {
      Context ctx = new InitialContext();
      pool = (DataSource)ctx.lookup("java:comp/env/jdbc/datasource_Servicio");
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }
  }

  static Gson j = new GsonBuilder()
		.registerTypeAdapter(byte[].class,new AdaptadorGsonBase64())
		.create();

  @POST
  @Path("alta_articulo")
  @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
  @Produces(MediaType.APPLICATION_JSON)
  public Response alta(@FormParam("articulo") Articulo articulo) throws Exception
  {
    Connection conexion = pool.getConnection();

    if (articulo.nombre == null || articulo.nombre.equals(""))
      return Response.status(400).entity(j.toJson(new Error("Se debe ingresar el nombre"))).build();

    if (articulo.descripcion == null || articulo.descripcion.equals(""))
    return Response.status(400).entity(j.toJson(new Error("Se debe ingresar una descripcion"))).build();

    

    try
    {
    
      PreparedStatement stmt_2 = conexion.prepareStatement("INSERT INTO articulos (Nombre,Descripcion,Precio,Cantidad,Foto) VALUES (?,?,?,?,?)");
      try
      {
    

        stmt_2.setString(1,articulo.nombre);
        stmt_2.setString(2,articulo.descripcion);
        stmt_2.setFloat(3,articulo.precio);
        stmt_2.setInt(4,articulo.cantidad);
        stmt_2.setBytes(5,articulo.foto);
        stmt_2.executeUpdate();
      }
      finally
      {
        stmt_2.close();
      }

      
    }
    catch (Exception e)
    {
      return Response.status(400).entity(j.toJson(new Error(e.getMessage()))).build();
    }
    finally
    {
      conexion.close();
    }
    return Response.ok().build();
  }

  @POST
  @Path("buscar_articulos")
  @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
  @Produces(MediaType.APPLICATION_JSON)
  public Response buscar_articulos(@FormParam("descripcion") String descripcion) throws Exception
  {
    Connection conexion = pool.getConnection();
    ArrayList<Articulo> lista = new ArrayList<Articulo>();
    
    try
    {
    
      PreparedStatement stmt_2 = conexion.prepareStatement("SELECT * FROM articulos WHERE Descripcion LIKE ?");
      try
      {
        stmt_2.setString(1,"%"+descripcion+"%");
        ResultSet rs =stmt_2.executeQuery();

        while ( rs.next() )
        {
          Articulo articulo = new Articulo();
          articulo.identificador=rs.getInt("IDArticulo");
          articulo.nombre=rs.getString("Nombre");
          articulo.descripcion=rs.getString("Descripcion");
          articulo.precio=rs.getFloat("Precio");
          articulo.cantidad=rs.getInt("Cantidad");
          articulo.foto=rs.getBytes("Foto");
          lista.add(articulo);
    
          
        }
        return Response.ok().entity(j.toJson(lista)).build();
      }
      finally
      {
        stmt_2.close();
      }

      
    }
    catch (Exception e)
    {
      return Response.status(400).entity(j.toJson(new Error(e.getMessage()))).build();
    }
    finally
    {
      conexion.close();
    }
   
  }

  @POST
  @Path("comprar_articulo")
  @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
  @Produces(MediaType.APPLICATION_JSON)
  public Response comprar_articulo(@FormParam("cantidad") int cantidad,@FormParam("identificador") int  identificador ) throws Exception
  {
    Connection conexion = pool.getConnection();
    
    
    try
    {
      conexion.setAutoCommit(false);
      conexion.setTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
      PreparedStatement stmt_2 = conexion.prepareStatement("SELECT Cantidad FROM articulos WHERE IDArticulo=?");
      PreparedStatement stmt_3 = conexion.prepareStatement("INSERT INTO carrito_compra (IDArticulo,Cantidad) VALUES (?,?)");
      PreparedStatement stmt_4 = conexion.prepareStatement("UPDATE articulos SET Cantidad = ? WHERE IDArticulo = ?");
      try
      {
        stmt_2.setInt(1,identificador);
        ResultSet rs =stmt_2.executeQuery();
        int cantidadDB=0;
        while(rs.next()){
               cantidadDB=rs.getInt("Cantidad");
        }
        if(cantidadDB >= cantidad){
                try{
                //  conexion.setAutoCommit(false);
                 // PreparedStatement stmt_3 = conexion.prepareStatement("INSERT INTO carrito_compra (IDArticulo,Cantidad) VALUES (?,?)");

                  stmt_3.setInt(1, identificador);
                  stmt_3.setInt(2, cantidad);
                  stmt_3.executeUpdate();
                
                //  PreparedStatement stmt_4 = conexion.prepareStatement("UPDATE articulos SET Cantidad = ? WHERE IDArticulo = ?");

                  stmt_4.setInt(1, (cantidadDB - cantidad));
                  stmt_4.setInt(2, identificador);
                  stmt_4.executeUpdate();

                  conexion.commit();

                }catch(Exception e){
                      conexion.rollback();
                }
        }else{
                  
          return Response.status(400).entity(j.toJson(new Error("Solo se tienen " +Integer.toString(cantidadDB)+" elementos del articulo"))).build();  

        }
      
        return Response.ok().build();
      }
      finally
      {
        stmt_2.close();
        stmt_3.close();
        stmt_4.close();
      }

      
    }
    catch (Exception e)
    {
      return Response.status(400).entity(j.toJson(new Error(e.getMessage()))).build();
    }
    finally
    {
      conexion.close();
    }
   
  }
  

  @POST
  @Path("traer_carrito")
  @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
  @Produces(MediaType.APPLICATION_JSON)
  public Response traer_carrito() throws Exception
  {
    Connection conexion = pool.getConnection();
    ArrayList<Compra> lista = new ArrayList<Compra>();
    
    try
    {
    
      PreparedStatement stmt_2 = conexion.prepareStatement("select carrito_compra.IDCompra,articulos.nombre,articulos.foto,articulos.descripcion,carrito_compra.cantidad ,"+
      " articulos.precio,carrito_compra.cantidad*articulos.precio as costo "+
      " from articulos, carrito_compra  WHERE articulos.IDArticulo =carrito_compra.IDArticulo");
      try
      {
        ResultSet rs =stmt_2.executeQuery();

        while ( rs.next() )
        {
          Compra compra = new Compra();
          compra.identificador=rs.getInt("carrito_compra.IDCompra");
          compra.nombre=rs.getString("articulos.nombre");
          compra.descripcion=rs.getString("articulos.descripcion");
          compra.precio=rs.getFloat("articulos.precio");
          compra.cantidad=rs.getInt("carrito_compra.cantidad");
          compra.costo=rs.getFloat("costo");
          compra.foto=rs.getBytes("Foto");
          lista.add(compra);
    
          
        }
        return Response.ok().entity(j.toJson(lista)).build();
      }
      finally
      {
        stmt_2.close();
      }

      
    }
    catch (Exception e)
    {
      return Response.status(400).entity(j.toJson(new Error(e.getMessage()))).build();
    }
    finally
    {
      conexion.close();
    }
  
  }


  @POST
  @Path("eliminar_compra")
  @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
  @Produces(MediaType.APPLICATION_JSON)
  public Response eliminar_compra(@FormParam("identificador") int identificador) throws Exception
  {
    Connection conexion = pool.getConnection();

  

    try
    {
      conexion.setAutoCommit(false);
      conexion.setTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
      PreparedStatement stmt_1 = conexion.prepareStatement("SELECT Cantidad,IDArticulo FROM carrito_compra WHERE  IDCompra =  ?");
      PreparedStatement stmt_2 = conexion.prepareStatement("SELECT Cantidad FROM articulos WHERE  IDArticulo =  ?");
      PreparedStatement stmt_3 = conexion.prepareStatement("  UPDATE articulos SET Cantidad = ? WHERE IDArticulo = ?");
      PreparedStatement stmt_4 = conexion.prepareStatement("DELETE FROM carrito_compra WHERE  IDCompra =  ?");
      try
      {
       
        //PreparedStatement stmt_1 = conexion.prepareStatement("SELECT Cantidad,IDArticulo FROM carrito_compra WHERE  IDCompra =  ?");
        stmt_1.setInt(1,identificador);
        ResultSet rs1 =stmt_1.executeQuery();
        int cantidadRegresar=0;
        int idArticulo = 0;
        while ( rs1.next() )
        {
        
          cantidadRegresar=rs1.getInt("Cantidad");  
          idArticulo = rs1.getInt("IDArticulo");
        }

       // PreparedStatement stmt_2 = conexion.prepareStatement("SELECT Cantidad FROM articulos WHERE  IDArticulo =  ?");
        stmt_2.setInt(1,idArticulo);
        ResultSet rs2 =stmt_2.executeQuery();
        int cantidaBase =0 ;
        while ( rs2.next() )
        {
        
          cantidaBase=rs2.getInt("Cantidad");  
        
        }


       // PreparedStatement stmt_3 = conexion.prepareStatement("  UPDATE articulos SET Cantidad = ? WHERE IDArticulo = ?");
        stmt_3.setInt(1,cantidaBase + cantidadRegresar);
        stmt_3.setInt(2, idArticulo);
        stmt_3.executeUpdate();

      //  PreparedStatement stmt_4 = conexion.prepareStatement("DELETE FROM carrito_compra WHERE  IDCompra =  ?");
        stmt_4.setInt(1,identificador);
        stmt_4.executeUpdate();

        conexion.commit();

      }catch (Exception e)
      {
        conexion.rollback();
        return Response.status(400).entity(j.toJson(new Error(e.getMessage()))).build();
      }
      finally
      {
        stmt_1.close();
        stmt_2.close();
        stmt_3.close();
        stmt_4.close();
      }

      
    }
    catch (Exception e)
    {
      return Response.status(400).entity(j.toJson(new Error(e.getMessage()))).build();
    }
    finally
    {
      conexion.close();
    }
    return Response.ok().build();
  }


  @POST
  @Path("eliminar_carrito")
  @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
  @Produces(MediaType.APPLICATION_JSON)
  public Response eliminar_carrito() throws Exception
  {
    Connection conexion = pool.getConnection();
    try
    {
      conexion.setAutoCommit(false);
      conexion.setTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
      ArrayList <Integer> listaCompras = new ArrayList<Integer>();
      PreparedStatement stmt_0 = conexion.prepareStatement("SELECT IDArticulo,Sum(cantidad) AS suma FROM carrito_compra  GROUP BY IDArticulo");

      try
      {

        ResultSet rs0 =stmt_0.executeQuery();
        while ( rs0.next() )
        {
          PreparedStatement stmt_1 = conexion.prepareStatement("SELECT Cantidad FROM articulos WHERE IDArticulo = ?");
          stmt_1.setInt(1,rs0.getInt("IDArticulo"));
          ResultSet rs1 =stmt_1.executeQuery();
          int cantidadInicial=0;
          while(rs1.next()){
               cantidadInicial=rs1.getInt("Cantidad");
          }
          rs1.close();

          PreparedStatement stmt_2 = conexion.prepareStatement("UPDATE articulos SET Cantidad = ? WHERE IDArticulo = ?");
          stmt_2.setInt(1,rs0.getInt("suma") +  cantidadInicial);
          stmt_2.setInt(2,rs0.getInt("IDArticulo"));
          stmt_2.executeUpdate();
          stmt_2.close();

        }

        PreparedStatement stmt_3 = conexion.prepareStatement("DELETE FROM carrito_compra WHERE IDCompra > 0");
        stmt_3.executeUpdate();
        stmt_3.close();
        conexion.commit();
        return Response.ok().build();

      } catch(Exception e){
        conexion.rollback();
        return Response.status(400).entity(j.toJson(new Error(e.getMessage()))).build();
      } finally{
        stmt_0.close();
      }


    }catch (Exception e)
    {
      return Response.status(400).entity(j.toJson(new Error(e.getMessage()))).build();
    }
    finally
    {
      conexion.close();
    }
    
  }

  
}
