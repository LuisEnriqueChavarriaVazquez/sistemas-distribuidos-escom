drop database if exists tienda;
create database tienda;
use tienda;
create table articulos(
IDArticulo int auto_increment not null,
Nombre varchar(50),
Descripcion varchar(100),
Precio float,
Cantidad int,
Foto longblob,
primary key (IDArticulo)
);

create table carrito_compra(
IDCompra int not null auto_increment,
IDArticulo int,
Cantidad int,
primary key (IDCompra),
foreign key (IDArticulo) references articulos(IDArticulo)
);

select * from articulos where Descripcion like '%palabra%';

INSERT INTO articulos (Nombre,Descripcion,Precio,Cantidad) VALUES ("mango","fruta",34.5,7);
INSERT INTO articulos (Nombre,Descripcion,Precio,Cantidad) VALUES ("atun","pez",67.5,12);
INSERT INTO articulos (Nombre,Descripcion,Precio,Cantidad) VALUES ("res","carne",59.8,57);
INSERT INTO articulos (Nombre,Descripcion,Precio,Cantidad) VALUES ("uva","fruta",43.5,9);
INSERT INTO articulos (Nombre,Descripcion,Precio,Cantidad) VALUES ("salmon","pez",79.5,23);
INSERT INTO articulos (Nombre,Descripcion,Precio,Cantidad) VALUES ("pollo","carne",99.8,79);

INSERT INTO carrito_compra (IDArticulo,Cantidad) VALUES (1,7);
INSERT INTO carrito_compra (IDArticulo,Cantidad) VALUES (5,12);
INSERT INTO carrito_compra (IDArticulo,Cantidad) VALUES (4,57);
INSERT INTO carrito_compra (IDArticulo,Cantidad) VALUES (3,7);
INSERT INTO carrito_compra (IDArticulo,Cantidad) VALUES (1,12);
INSERT INTO carrito_compra (IDArticulo,Cantidad) VALUES (5,57);

select IDArticulo,Sum(cantidad) group by IDArticulo;
 
 
