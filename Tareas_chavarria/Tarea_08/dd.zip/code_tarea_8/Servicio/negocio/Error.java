

package negocio;

public class Error
{
	String message;

	Error(String message)
	{
		this.message = message;
	}
}
