$(document).ready(function () {
    //Para el menu lateral
    $('.sidenav').sidenav();
    //Para el modal de eliminar elementos
    $('.modal').modal();
})