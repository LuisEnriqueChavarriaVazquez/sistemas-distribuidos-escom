
/*
************************************************
*
*__________________________________________________
* Datos de la práctica.
*__________________________________________________
*
* Materia: Desarrollo de Sistemas distribuidos
*
* Profesor: Carlos Pineda Guerrero
*
* Alumnos:
*           Cazares Martínez Maximiliano.
*           Chavarría Vázquez Luis Enrique.
*           Cipriano Damián Sebastián.
*
* Equipo 2
*
* Grupo: 4CV11
*
* Practica 05: Multiplicación de matrices usando objetos distribuidos
* 
************************************************
*/

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface InterfaceMatricesRMI extends Remote {
    public float[][] multiplicarMatrices(float[][] A, float[][] B, int N) throws RemoteException;
}