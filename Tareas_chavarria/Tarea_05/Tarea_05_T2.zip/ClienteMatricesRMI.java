

/*
************************************************
*
*__________________________________________________
* Datos de la práctica.
*__________________________________________________
*
* Materia: Desarrollo de Sistemas distribuidos
*
* Profesor: Carlos Pineda Guerrero
*
* Alumnos:
*           Cazares Martínez Maximiliano.
*           Chavarría Vázquez Luis Enrique.
*           Cipriano Damián Sebastián.
*
* Equipo 2
*
* Grupo: 4CV11
*
* Practica 05: Multiplicación de matrices usando objetos distribuidos
* 
************************************************
*/

import java.rmi.Naming;

public class ClienteMatricesRMI {

    // static int N = 8;
    static int N = 4000;

    static float[][] A = new float[N][N];
    static float[][] B = new float[N][N];
    static float[][] bT = new float[N][N];
    static float[][] C = new float[N][N];

    static float[][] A1 = new float[N/4][N];
    static float[][] A2 = new float[N/4][N];
    static float[][] A3 = new float[N/4][N];
    static float[][] A4 = new float[N/4][N];

    static float[][] B1 = new float[N/4][N];
    static float[][] B2 = new float[N/4][N];
    static float[][] B3 = new float[N/4][N];
    static float[][] B4 = new float[N/4][N];

    static float[][] C1 = new float[N/4][N/4];
    static float[][] C2 = new float[N/4][N/4];
    static float[][] C3 = new float[N/4][N/4];
    static float[][] C4 = new float[N/4][N/4];
    static float[][] C5 = new float[N/4][N/4];
    static float[][] C6 = new float[N/4][N/4];
    static float[][] C7 = new float[N/4][N/4];
    static float[][] C8 = new float[N/4][N/4];
    static float[][] C9 = new float[N/4][N/4];
    static float[][] C10 = new float[N/4][N/4];
    static float[][] C11 = new float[N/4][N/4];
    static float[][] C12 = new float[N/4][N/4];
    static float[][] C13 = new float[N/4][N/4];
    static float[][] C14 = new float[N/4][N/4];
    static float[][] C15 = new float[N/4][N/4];
    static float[][] C16 = new float[N/4][N/4];

    public static void main(String[] args) throws Exception {        
        String url1 = "rmi://10.0.0.5/nodo1";
        String url2 = "rmi://10.0.0.6/nodo2";
        String url3 = "rmi://10.0.0.7/nodo3";
        String url4 = "rmi://10.0.0.8/nodo4";

        InterfaceMatricesRMI nodo1 = (InterfaceMatricesRMI)Naming.lookup(url1);
        InterfaceMatricesRMI nodo2 = (InterfaceMatricesRMI)Naming.lookup(url2);
        InterfaceMatricesRMI nodo3 = (InterfaceMatricesRMI)Naming.lookup(url3);
        InterfaceMatricesRMI nodo4 = (InterfaceMatricesRMI)Naming.lookup(url4);
        
        // String[] IPnodos = {"", "", "", ""};
        // String[] IPnodos = {"localhost", "localhost", "localhost", "localhost"};
        // String[] nodosURL = new String[4];
        // InterfaceMatricesRMI[] nodos = new InterfaceMatricesRMI[4];

        // for (int i = 0; i < 4; i++) {
        //     nodosURL[i] = "rmi://" + IPnodos[i] + "/nodo" + (i+1);
        //     nodos[i] = (InterfaceMatricesRMI)Naming.lookup(nodosURL[i]);            
        // }

        inicializarMatrices();            
        trasponerB();

        A1 = separarMatriz(A, 0);        
        A2 = separarMatriz(A, N/4);        
        A3 = separarMatriz(A, N/2);        
        A4 = separarMatriz(A, (N*3)/4);        

        B1 = separarMatriz(bT, 0);        
        B2 = separarMatriz(bT, N/4);        
        B3 = separarMatriz(bT, N/2);        
        B4 = separarMatriz(bT, (N*3)/4);   
        
        // Operaciones del nodo 1
        C1 = nodo1.multiplicarMatrices(A1, B1, N);
        C2 = nodo1.multiplicarMatrices(A1, B2, N);
        C3 = nodo1.multiplicarMatrices(A1, B3, N);
        C4 = nodo1.multiplicarMatrices(A1, B4, N);

        // Operaciones del nodo 2
        C5 = nodo2.multiplicarMatrices(A2, B1, N);
        C6 = nodo2.multiplicarMatrices(A2, B2, N);
        C7 = nodo2.multiplicarMatrices(A2, B3, N);
        C8 = nodo2.multiplicarMatrices(A2, B4, N);

        // Operaciones del nodo 3
        C9 = nodo3.multiplicarMatrices(A3, B1, N);
        C10 = nodo3.multiplicarMatrices(A3, B2, N);
        C11 = nodo3.multiplicarMatrices(A3, B3, N);
        C12 = nodo3.multiplicarMatrices(A3, B4, N);

        // Operaciones del nodo 4
        C13 = nodo4.multiplicarMatrices(A4, B1, N);
        C14 = nodo4.multiplicarMatrices(A4, B2, N);
        C15 = nodo4.multiplicarMatrices(A4, B3, N);
        C16 = nodo4.multiplicarMatrices(A4, B4, N);

        // Agrupar las operaciones del nodo 1
        agruparC(C1, 0, 0);
        agruparC(C2, 0, N/4);
        agruparC(C3, 0, N/2);
        agruparC(C4, 0, (N*3)/4);

        // Agrupar las operaciones del nodo 2
        agruparC(C5, N/4, 0);
        agruparC(C6, N/4, N/4);
        agruparC(C7, N/4, N/2);
        agruparC(C8, N/4, (N*3)/4);

        // Agrupar las operaciones del nodo 3
        agruparC(C9,  N/2, 0);
        agruparC(C10, N/2, N/4);
        agruparC(C11, N/2, N/2);
        agruparC(C12, N/2, (N*3)/4);

        // Agrupar las operaciones del nodo 4
        agruparC(C13, 3*N/4, 0);
        agruparC(C14, 3*N/4, N/4);
        agruparC(C15, 3*N/4, N/2);
        agruparC(C16, 3*N/4, (N*3)/4);

        if(N == 8){
            // System.out.println("Matriz A");
            // imprimirMatriz(A, N, N);
    
            System.out.println("--------------------------");
            System.out.println("Matriz B");
            System.out.println("--------------------------");

            imprimirMatriz(B, N, N);

            System.out.println("--------------------------");
            System.out.println("Matriz B Traspuesta");
            System.out.println("--------------------------");
            imprimirMatriz(bT, N, N);

            // System.out.println("Matriz C");
            // imprimirMatriz(C, N, N);

            // System.out.println("Matriz A1");
            // imprimirMatriz(A1, N/4, N);
            // System.out.println("Matriz A2");
            // imprimirMatriz(A2, N/4, N);
            // System.out.println("Matriz A3");
            // imprimirMatriz(A3, N/4, N);
            // System.out.println("Matriz A4");
            // imprimirMatriz(A4, N/4, N);

            // System.out.println("Matriz B1");
            // imprimirMatriz(B1, N/4, N);
            // System.out.println("Matriz B2");
            // imprimirMatriz(B2, N/4, N);
            // System.out.println("Matriz B3");
            // imprimirMatriz(B3, N/4, N);
            // System.out.println("Matriz B4");
            // imprimirMatriz(B4, N/4, N);
            
            // System.out.println("Matriz C1");
            // imprimirMatriz(C1, N/4, N/4);
            // System.out.println("Matriz C2");
            // imprimirMatriz(C2, N/4, N/4);
            // System.out.println("Matriz C3");
            // imprimirMatriz(C3, N/4, N/4);
            // System.out.println("Matriz C4");
            // imprimirMatriz(C4, N/4, N/4);
        }

        // chechsum(8) = 53760.0
        // checksum(4000) = 1.99470445E18 - 6.1062471E17
        System.out.println("--------------------------");
        System.out.println("Checksum = " + calcularChecksum(C));
        System.out.println("--------------------------");
    }

    public static void inicializarMatrices() {
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                A[i][j] = i + 2 * j;
                B[i][j] = 3 * i - j;
                bT[i][j] = 3 * i - j;
            }
        }
    }

    public static void trasponerB() {
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < i; j++) {
                float x = bT[i][j];
                bT[i][j] = bT[j][i];
                bT[j][i] = x;
            }
        }
    }

    public static float[][] separarMatriz(float[][] A, int inicio) {
        float M[][] = new float [N/4][N];
        for (int i = 0; i < N/4; i++) {
            for (int j = 0; j < N; j++) {
                M[i][j] = A[i + inicio][j];
            }
        }
        return M;
    }

    public static void agruparC(float[][] M, int inicio, int fin) {
        for (int i = 0; i < N/4; i++){
            for (int j = 0; j < N/4; j++) {
                C[i + inicio][j + fin] = M[i][j];
            }
        } 
    }

    public static float calcularChecksum(float[][] M) {
        float checksum = 0;
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                checksum += M[i][j];
            }
        }
        return checksum;
    } 
    
    public static void imprimirMatriz(float[][] m, int filas, int columnas) {
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                System.out.print(m[i][j] + " ");
            }
            System.out.println("\n");
        }
    }
    
}